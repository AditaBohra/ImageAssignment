package com.example.viewpagertablayout;

import android.content.Context;
import androidx.annotation.NonNull;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;



public class ViewPagerAdapter extends PagerAdapter {

    private Context mContext;
    private Integer [] mImages = {R.drawable.image1,R.drawable.image2,R.drawable.image3,R.drawable.image4};
    private int mCount = mImages.length;


    public ViewPagerAdapter(Context context){
        this.mContext = context;
    }
    @Override
    public int getCount() {
        if(mCount>15){
            int removedCount = mImages.length - 15;
            return mImages.length - removedCount;
        }
        else {
            return mImages.length;
        }

    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == o;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.custom_layout, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
        imageView.setImageResource(mImages[position]);


        ViewPager vp = (ViewPager) container;
        vp.addView(view, 0);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        ViewPager vp = (ViewPager) container;
        View view = (View) object;
        vp.removeView(view);
    }


}
